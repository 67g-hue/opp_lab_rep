# Java OOP Labs and Library Mini-Project

This project contains Java examples for different lab topics. Each lab has its own package and example class. Keeping them separate avoids clashes between classes with the same name, such as Student, Book, Circle, and Rectangle.

## Requirements

Install JDK 17 or a newer version. The code uses some features that are available in these versions of Java.

## Compile the code

Open PowerShell in this folder and run:

```powershell
New-Item -ItemType Directory -Force out | Out-Null
javac -d out (Get-ChildItem -Recurse src -Filter *.java | ForEach-Object FullName)
```

## Run a lab

For example, to run Lab 1, use:

```powershell
java -cp out lab01.ClassesAndObjects
```

The main classes you can run are:

- `lab01.ClassesAndObjects`
- `lab02.ConstructorsAndStatic`
- `lab03.Encapsulation`
- `lab04.Inheritance`
- `lab05.Polymorphism`
- `lab06.AbstractionAndInterfaces`
- `lab07.Exceptions` (asks you to enter two integers)
- `lab08.CollectionsAndGenerics`
- `lab09.TypesAndObjectContract`
- `lab10.FilesLambdasAndStreams` (asks for five lines, or you can give exactly five command-line arguments)
- `miniproject.Library`

Lab 10 saves sample results in the `lab10-output` folder. If there is a file called `learners.csv` in the working folder, it should have a header and then rows with a name and mark. The program uses it to create three grade reports.

## Library mini-project

Run `miniproject.Library` to start the library program. It creates or loads these files in the `library-data` folder: `items.csv`, `members.csv`, and `loans.csv`. The program has a menu and saves changes when you exit.

Items and members are identified by their IDs. Active loans are saved, so they are still there when the program is started again. The original due dates are also saved. Books can be borrowed for 21 days and DVDs for 7 days. Each member can have up to three items on loan at a time.

## Design report

`LibraryItem` is an abstract class and uses the `Borrowable` interface. `Book` and `Dvd` are based on `LibraryItem` and have their own loan periods and details.

The `Library` class keeps records of items, members, and loans. It also handles borrowing limits, saving and loading CSV files, searching, and finding overdue items. The program checks that the information entered is valid. It uses `ItemNotAvailableException` and `MemberLimitExceededException` to show common borrowing problems. If a file has bad data or cannot be read, the program reports the problem instead of ignoring it.

## Class diagram

```text
                         <<interface>> Borrowable
                         + borrow(Member)
                         + giveBack()
                                  ^
                                  |
                         LibraryItem (abstract)
                         - id, title, borrowedBy, dueDate
                         + loanPeriodDays()
                           ^             ^
                           |             |
                     Book                Dvd
                     - isbn, author      - director

  Library
  - Map<String, LibraryItem> items
  - Map<String, Member> members
  - Map<String, Loan> loans
  + add/register/borrow/giveBack/search/overdue/load/save

  Loan - id, itemId, memberId, borrowedOn, dueDate, returnedOn
  Member - id, name, email
```

The lab examples show the results for questions that can be checked by running the code. The notes below explain what happens in each lab.

## Lab explanation notes

- Lab 1: `r2 = r1` copies the reference to the same rectangle. It does not make a new rectangle. This means a change made through `r2` can also be seen through `r1`. If `address` is null, trying to use a field inside it causes a `NullPointerException`. Check that the address exists before using it.

- Lab 2: Static setup code runs once, before the first object is created. Instance setup code runs for each new object, just before its constructor. Factory methods such as `fromCelsius` and `fromFahrenheit` make it clear which temperature unit is being used.

- Lab 3: `ImmutablePerson` cannot be extended because it is marked `final`. Its fields are private and final, so they are set once and accessed through methods. Keeping a temperature in Kelvin and providing Celsius and Fahrenheit methods means users do not need to know how it is stored.

- Lab 4: `Dog` must call `super(name)` because the parent class does not have a constructor with no arguments. Using `ArrayList` directly for a stack allows list actions that a stack should not allow. Using another list inside the stack keeps the stack actions limited to what is needed.

- Lab 5: An overridden method runs based on the actual object. Fields, however, are chosen based on the type of the reference. A payment system that checks every payment type with `instanceof` must be changed when a new type is added. Using a `process()` method for each payment type avoids that problem.

- Lab 6: If two interfaces have a default method with the same name, the class must write its own version. It can choose an interface's version by using `InterfaceName.super.method()`.

- Lab 7: A checked exception makes the code using a method handle the problem or declare that it may happen. This can make the code longer, but it separates errors from normal return values. A `finally` block runs when the `try` block ends, even if it returns, unless the program is stopped or the JVM exits.

- Lab 8: Java generics use object types, not primitive types such as `int`. Use `Integer[]` instead of `int[]` when working with generics. Java can automatically convert individual `int` values to `Integer` objects, but it does not convert a whole `int[]` into an `Integer[]`.

- Lab 9: `HashSet` uses `hashCode()` to find where an item should go and `equals()` to check whether an item is already there. Both methods should use the same rule for deciding when two objects are equal. In this example, that rule is the ISBN.
