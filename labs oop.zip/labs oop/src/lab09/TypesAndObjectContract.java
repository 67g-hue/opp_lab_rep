package lab09;

import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

public class TypesAndObjectContract {
    enum Level { LOW, MEDIUM, HIGH }
    enum Coin {
        PENNY(1), NICKEL(5), DIME(10), QUARTER(25);
        final int cents;
        Coin(int cents) { this.cents = cents; }
        static int[] fewestCoins(int amount) {
            if (amount < 0) throw new IllegalArgumentException("Amount cannot be negative");
            int[] counts = new int[Coin.values().length];
            Coin[] coins = Coin.values();
            for (int index = coins.length - 1; index >= 0; index--) {
                counts[index] = amount / coins[index].cents;
                amount %= coins[index].cents;
            }
            return counts;
        }
    }
    record Student(String name, int age) {}

    static class Book {
        private final String isbn;
        private final String title;
        Book(String isbn, String title) {
            if (isbn == null || isbn.isBlank()) throw new IllegalArgumentException("ISBN required");
            this.isbn = isbn;
            this.title = Objects.requireNonNull(title);
        }
        @Override public boolean equals(Object other) {
            return other instanceof Book book && isbn.equals(book.isbn);
        }
        @Override public int hashCode() { return isbn.hashCode(); }
        @Override public String toString() { return title + " (" + isbn + ")"; }
    }

    static class SimpleLinkedList<T> implements Iterable<T> {
        private static class Node<T> {
            final T value;
            Node<T> next;
            Node(T value) { this.value = value; }
        }
        private Node<T> head;
        private Node<T> tail;
        void add(T value) {
            Node<T> node = new Node<>(value);
            if (tail == null) head = node;
            else tail.next = node;
            tail = node;
        }
        @Override public Iterator<T> iterator() {
            return new Iterator<>() {
                private Node<T> current = head;
                @Override public boolean hasNext() { return current != null; }
                @Override public T next() {
                    if (!hasNext()) throw new NoSuchElementException();
                    T value = current.value;
                    current = current.next;
                    return value;
                }
            };
        }
    }

    public static void main(String[] args) {
        for (Level level : Level.values()) {
            String advice = switch (level) {
                case LOW -> "Keep monitoring.";
                case MEDIUM -> "Plan a response.";
                case HIGH -> "Act now.";
            };
            System.out.println(level + ": " + advice);
        }

        Student one = new Student("Rae", 20);
        Student two = new Student("Rae", 20);
        System.out.println(one + "; equal records=" + one.equals(two) + "; name=" + one.name());

        HashSet<Book> books = new HashSet<>();
        books.add(new Book("978-1", "First edition"));
        boolean duplicateAdded = books.add(new Book("978-1", "Another copy"));
        System.out.println("Book set size=" + books.size() + "; duplicate accepted=" + duplicateAdded);

        SimpleLinkedList<String> list = new SimpleLinkedList<>();
        list.add("one");
        list.add("two");
        for (String value : list) System.out.println("List value: " + value);

        int amount = 87;
        int[] counts = Coin.fewestCoins(amount);
        System.out.printf("%d cents: quarters=%d, dimes=%d, nickels=%d, pennies=%d%n",
                amount, counts[3], counts[2], counts[1], counts[0]);
    }
}
