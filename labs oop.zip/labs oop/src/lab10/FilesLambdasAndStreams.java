package lab10;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class FilesLambdasAndStreams {
    record Student(String name, int mark) {}
    record Learner(String name, int mark) {}

    static String gradeBand(int mark) {
        if (mark >= 80) return "A";
        if (mark >= 60) return "B";
        return "C";
    }

    static void writeLearnerReports(Path csvFile, Path outputDirectory) throws IOException {
        Map<String, List<Learner>> grouped = Files.readAllLines(csvFile).stream()
                .skip(1)
                .filter(line -> !line.isBlank())
                .map(line -> line.split(",", -1))
                .map(parts -> {
                    if (parts.length != 2) throw new IllegalArgumentException("Invalid learners.csv row");
                    return new Learner(parts[0].trim(), Integer.parseInt(parts[1].trim()));
                })
                .collect(Collectors.groupingBy(learner -> gradeBand(learner.mark())));
        Files.createDirectories(outputDirectory);
        for (String band : List.of("A", "B", "C")) {
            List<Learner> learners = grouped.getOrDefault(band, List.of());
            Path report = outputDirectory.resolve("grade-" + band + ".txt");
            Files.write(report, learners.stream()
                    .map(learner -> learner.name() + "," + learner.mark()).toList());
        }
    }

    static void saveAndReadFiveLines(Path file, List<String> lines) throws IOException {
        if (lines.size() != 5) throw new IllegalArgumentException("Exactly five lines are required");
        Files.write(file, lines);
        Files.readAllLines(file).forEach(System.out::println);
    }

    public static void main(String[] args) throws IOException {
        Path output = Path.of("lab10-output");
        Path fiveLines = output.resolve("five-lines.txt");
        Files.createDirectories(output);
        List<String> lines = new ArrayList<>();
        if (args.length == 5) {
            lines.addAll(List.of(args));
        } else {
            try (Scanner scanner = new Scanner(System.in)) {
                for (int index = 1; index <= 5; index++) {
                    System.out.print("Enter line " + index + " of 5: ");
                    lines.add(scanner.nextLine());
                }
            }
        }
        saveAndReadFiveLines(fiveLines, lines);

        List<Integer> values = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6));
        Predicate<Integer> isEven = number -> number % 2 == 0;
        values.removeIf(isEven);
        System.out.println("After removing even numbers: " + values);

        Path textFile = output.resolve("sample.txt");
        Files.writeString(textFile, "Streams count words. Files count lines too.\nJava streams!");
        List<String> textLines = Files.readAllLines(textFile);
        long words = textLines.stream().flatMap(line -> Arrays.stream(line.trim().split("\\s+")))
                .filter(word -> !word.isBlank()).count();
        long characters = Files.readString(textFile).length();
        System.out.printf("Lines=%d, words=%d, characters=%d%n", textLines.size(), words, characters);

        List<Student> students = List.of(new Student("Zoe", 90), new Student("Ali", 75),
                new Student("Bea", 85), new Student("Max", 60));
        double average = students.stream().mapToInt(Student::mark).average().orElse(0);
        System.out.println("Above class average (" + average + "):");
        students.stream().filter(student -> student.mark() > average)
                .map(Student::name).sorted().forEach(System.out::println);

        Path learnerCsv = Path.of("learners.csv");
        if (Files.exists(learnerCsv)) {
            writeLearnerReports(learnerCsv, output.resolve("grade-reports"));
            System.out.println("Grade-band reports written under " + output.resolve("grade-reports"));
        } else {
            System.out.println("Optional challenge skipped: put learners.csv (name,mark) in the working directory.");
        }
    }
}
