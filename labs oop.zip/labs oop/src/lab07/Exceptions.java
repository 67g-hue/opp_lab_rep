package lab07;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Exceptions {
    static class InvalidAgeException extends Exception {
        private static final long serialVersionUID = 1L;
        InvalidAgeException(String message) { super(message); }
    }
    static class InsufficientFundsException extends Exception {
        private static final long serialVersionUID = 1L;
        InsufficientFundsException(String message) { super(message); }
    }
    static class BankAccount {
        private double balance;
        private final List<String> transactions = new ArrayList<>();
        BankAccount(double balance) {
            if (balance < 0) throw new IllegalArgumentException("Opening balance cannot be negative");
            this.balance = balance;
            transactions.add("Opened: " + balance);
        }
        void deposit(double amount) {
            if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
            balance += amount;
            transactions.add("Deposit: " + amount);
        }
        void withdraw(double amount) throws InsufficientFundsException {
            if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
            if (amount > balance) throw new InsufficientFundsException("Not enough funds");
            balance -= amount;
            transactions.add("Withdrawal: " + amount);
        }
        List<String> transactions() {
            return Collections.unmodifiableList(new ArrayList<>(transactions));
        }
    }
    static void validateAge(int age) throws InvalidAgeException {
        if (age < 0 || age > 120) throw new InvalidAgeException("Age must be between 0 and 120");
    }
    static int safeElement(int[] values, int index) {
        try {
            return values[index];
        } catch (ArrayIndexOutOfBoundsException exception) {
            System.out.println("Index is outside the array.");
            return 0;
        }
    }
    static int returnWithFinally() {
        try {
            return 7;
        } finally {
            System.out.println("finally runs before the return completes");
        }
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter two integers to divide (invalid input is handled): ");
            try {
                int dividend = scanner.nextInt();
                int divisor = scanner.nextInt();
                System.out.println("Result: " + (dividend / divisor));
            } catch (InputMismatchException exception) {
                System.out.println("Please enter integers.");
            } catch (ArithmeticException exception) {
                System.out.println("Cannot divide by zero.");
            }
        }
        System.out.println("Array value: " + safeElement(new int[] {4, 8}, 5));
        try {
            validateAge(150);
        } catch (InvalidAgeException exception) {
            System.out.println(exception.getMessage());
        }
        BankAccount account = new BankAccount(100);
        account.deposit(50);
        try {
            account.withdraw(30);
        } catch (InsufficientFundsException exception) {
            System.out.println(exception.getMessage());
        }
        try {
            account.withdraw(200);
        } catch (InsufficientFundsException exception) {
            System.out.println(exception.getMessage()
                    + " (exceptions separate failure from normal return values, but require handling)");
        }
        System.out.println("Transaction history: " + account.transactions());
        System.out.println("Returned value: " + returnWithFinally());
    }
}
