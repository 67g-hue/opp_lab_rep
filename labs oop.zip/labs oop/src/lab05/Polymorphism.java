package lab05;

public class Polymorphism {
    static void print(int value) { System.out.println("int: " + value); }
    static void print(double value) { System.out.println("double: " + value); }
    static void print(String value) { System.out.println("String: " + value); }
    static void print(int[] value) { System.out.println("int[] length: " + value.length); }

    static class Animal {
        String kind = "animal";
        String sound() { return "some sound"; }
    }
    static class Cat extends Animal {
        String kind = "cat";
        @Override String sound() { return "meow"; }
    }
    static class Cow extends Animal { @Override String sound() { return "moo"; } }
    static class Duck extends Animal { @Override String sound() { return "quack"; } }

    static class Employee {
        final double monthlySalary;
        Employee(double monthlySalary) { this.monthlySalary = monthlySalary; }
        double payroll() { return monthlySalary; }
    }
    static class Intern extends Employee {
        Intern(double stipend) { super(stipend); }
        @Override double payroll() { return monthlySalary * 0.8; }
    }

    interface Payment { double amount(); }
    record CardPayment(double amount, String lastFourDigits) implements Payment {}
    record MobileMoneyPayment(double amount, String phoneNumber) implements Payment {}
    static class PaymentProcessor {
        void payWithTypeChecks(Payment payment) {
            if (payment instanceof CardPayment card) {
                System.out.println("Charge card ending " + card.lastFourDigits() + ": " + card.amount());
            } else if (payment instanceof MobileMoneyPayment mobile) {
                System.out.println("Charge mobile " + mobile.phoneNumber() + ": " + mobile.amount());
            } else {
                throw new IllegalArgumentException("Unsupported payment type");
            }
        }
    }
    interface ProcessablePayment extends Payment { void process(); }
    record ProcessableCardPayment(double amount, String lastFourDigits) implements ProcessablePayment {
        @Override public void process() { System.out.println("Charge card ending " + lastFourDigits + ": " + amount); }
    }
    record ProcessableMobilePayment(double amount, String phoneNumber) implements ProcessablePayment {
        @Override public void process() { System.out.println("Charge mobile " + phoneNumber + ": " + amount); }
    }

    public static void main(String[] args) {
        print(4);
        print(3.5);
        print("hello");
        print(new int[] {1, 2});
        Animal[] animals = {new Cat(), new Cow(), new Duck()};
        for (Animal animal : animals) System.out.println(animal.sound());

        Employee[] team = {new Employee(3000), new Intern(1000), new Employee(2500)};
        double total = 0;
        for (Employee employee : team) total += employee.payroll();
        System.out.println("Mixed payroll: " + total);

        Animal cat = new Cat();
        System.out.println("Overridden method: " + cat.sound() + "; hidden field: " + cat.kind);
        System.out.println("Methods dispatch dynamically; fields are selected from the reference's declared type.");
        PaymentProcessor processor = new PaymentProcessor();
        processor.payWithTypeChecks(new CardPayment(20, "1234"));
        processor.payWithTypeChecks(new MobileMoneyPayment(15, "+254700000000"));
        ProcessablePayment[] payments = {
            new ProcessableCardPayment(20, "1234"), new ProcessableMobilePayment(15, "+254700000000")
        };
        for (ProcessablePayment payment : payments) payment.process();
    }
}
