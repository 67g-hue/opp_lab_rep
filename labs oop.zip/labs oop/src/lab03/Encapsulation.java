package lab03;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Encapsulation {
    static class Student {
        private final String name;
        private int marks;
        Student(String name, int marks) {
            this.name = name;
            setMarks(marks);
        }
        void setMarks(int marks) {
            if (marks < 0 || marks > 100) throw new IllegalArgumentException("Marks must be 0..100");
            this.marks = marks;
        }
        String getGrade() {
            if (marks >= 80) return "A";
            if (marks >= 60) return "B";
            if (marks >= 40) return "C";
            return "F";
        }
        @Override public String toString() { return name + ": " + marks + " (" + getGrade() + ")"; }
    }

    static class BankAccount {
        private double balance;
        private final List<String> transactions = new ArrayList<>();
        BankAccount(double openingBalance) {
            if (openingBalance < 0) throw new IllegalArgumentException("Negative opening balance");
            balance = openingBalance;
            transactions.add("Opened: " + openingBalance);
        }
        void deposit(double amount) {
            if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
            balance += amount;
            transactions.add("Deposit: " + amount);
        }
        double balance() { return balance; }
        List<String> transactions() {
            return Collections.unmodifiableList(new ArrayList<>(transactions));
        }
    }

    static final class ImmutablePerson {
        private final String name;
        private final int age;
        ImmutablePerson(String name, int age) {
            if (name == null || name.isBlank() || age < 0) throw new IllegalArgumentException();
            this.name = name;
            this.age = age;
        }
        String name() { return name; }
        int age() { return age; }
    }

    static class KelvinTemperature {
        private final double kelvin;
        KelvinTemperature(double kelvin) {
            if (kelvin < 0) throw new IllegalArgumentException("Below absolute zero");
            this.kelvin = kelvin;
        }
        double getCelsius() { return kelvin - 273.15; }
        double getFahrenheit() { return getCelsius() * 9 / 5 + 32; }
    }

    public static void main(String[] args) {
        Student student = new Student("Mina", 87);
        System.out.println(student);
        try {
            student.setMarks(101);
        } catch (IllegalArgumentException exception) {
            System.out.println("Invalid marks rejected: " + exception.getMessage());
        }

        BankAccount account = new BankAccount(100);
        account.deposit(25);
        System.out.println("Balance: " + account.balance() + "; history: " + account.transactions());
        try {
            account.transactions().add("forged");
        } catch (UnsupportedOperationException exception) {
            System.out.println("Transaction history is a defensive, unmodifiable copy.");
        }
        ImmutablePerson person = new ImmutablePerson("Noah", 20);
        System.out.println("Immutable person: " + person.name() + ", " + person.age());
        KelvinTemperature temperature = new KelvinTemperature(300);
        System.out.printf("Temperature: %.2f C, %.2f F%n",
                temperature.getCelsius(), temperature.getFahrenheit());
        System.out.println("Kelvin is private; callers depend on stable conversion methods, not storage units.");
    }
}
