package lab08;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class CollectionsAndGenerics {
    static class Stack<T> {
        private final ArrayList<T> values = new ArrayList<>();
        void push(T value) { values.add(value); }
        T pop() {
            if (isEmpty()) throw new IllegalStateException("Stack is empty");
            return values.remove(values.size() - 1);
        }
        T peek() {
            if (isEmpty()) throw new IllegalStateException("Stack is empty");
            return values.get(values.size() - 1);
        }
        boolean isEmpty() { return values.isEmpty(); }
    }

    static <T extends Comparable<T>> void bubbleSort(T[] array) {
        for (int end = array.length - 1; end > 0; end--) {
            boolean changed = false;
            for (int index = 0; index < end; index++) {
                if (array[index].compareTo(array[index + 1]) > 0) {
                    T temporary = array[index];
                    array[index] = array[index + 1];
                    array[index + 1] = temporary;
                    changed = true;
                }
            }
            if (!changed) return;
        }
    }

    static Map<String, Integer> wordFrequencies(String paragraph) {
        Map<String, Integer> frequencies = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (String word : paragraph.toLowerCase().split("[^\\p{L}\\p{N}']+")) {
            if (!word.isBlank()) frequencies.merge(word, 1, Integer::sum);
        }
        return frequencies;
    }

    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(List.of(7, 2, 9, 1, 5, 4, 10, 3, 6, 8));
        int sum = numbers.stream().mapToInt(Integer::intValue).sum();
        int maximum = numbers.stream().mapToInt(Integer::intValue).max().orElseThrow();
        List<Integer> reversed = new ArrayList<>(numbers);
        java.util.Collections.reverse(reversed);
        System.out.println("Sum=" + sum + ", max=" + maximum + ", reverse=" + reversed);

        Set<String> uniqueNames = new LinkedHashSet<>(List.of("Ada", "Bo", "Ada", "Chen"));
        System.out.println("Unique names: " + uniqueNames);

        Stack<String> stack = new Stack<>();
        stack.push("first");
        stack.push("second");
        System.out.println("Stack peek/pop: " + stack.peek() + "/" + stack.pop()
                + "; empty=" + stack.isEmpty());

        Map<String, Integer> frequencies = wordFrequencies("Java is fun; Java is useful. Fun!");
        frequencies.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed()
                        .thenComparing(Map.Entry.comparingByKey()))
                .forEach(entry -> System.out.println(entry.getKey() + ": " + entry.getValue()));

        Integer[] integers = {5, 1, 3, 2, 4};
        String[] words = {"pear", "apple", "orange"};
        bubbleSort(integers);
        bubbleSort(words);
        System.out.println(Arrays.toString(integers));
        System.out.println(Arrays.toString(words));
        System.out.println("int[] cannot be passed because generics require reference types; use Integer[].");
    }
}
