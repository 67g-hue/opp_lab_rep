package miniproject;

import java.util.Objects;

public final class Book extends LibraryItem {
    private final String isbn;
    private final String author;

    public Book(String title, String id, String isbn, String author) {
        super(title, id);
        this.isbn = requireText(isbn, "ISBN");
        this.author = requireText(author, "author");
    }

    private static String requireText(String value, String field) {
        Objects.requireNonNull(value, field + " is required");
        if (value.isBlank()) throw new IllegalArgumentException(field + " cannot be blank");
        return value.trim();
    }

    public String isbn() { return isbn; }
    public String author() { return author; }
    @Override public int loanPeriodDays() { return 21; }
    @Override public String itemType() { return "BOOK"; }
    @Override public String csvDetails() { return isbn + "," + author; }
    @Override public String toString() { return super.toString() + " by " + author + " (ISBN " + isbn + ")"; }
}
