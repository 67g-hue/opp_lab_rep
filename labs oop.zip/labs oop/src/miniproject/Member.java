package miniproject;

import java.util.Objects;

public final class Member {
    private final String id;
    private final String name;
    private final String email;

    public Member(String id, String name, String email) {
        this.id = requireText(id, "id");
        this.name = requireText(name, "name");
        this.email = requireText(email, "email");
        if (!email.contains("@")) throw new IllegalArgumentException("Email must contain @");
    }

    private static String requireText(String value, String field) {
        Objects.requireNonNull(value, field + " is required");
        if (value.isBlank()) throw new IllegalArgumentException(field + " cannot be blank");
        return value.trim();
    }

    public String id() { return id; }
    public String name() { return name; }
    public String email() { return email; }

    @Override public String toString() { return id + " - " + name + " <" + email + ">"; }
}
