package miniproject;

import java.time.LocalDate;
import java.util.Objects;

public final class Loan {
    private final String id;
    private final String itemId;
    private final String memberId;
    private final LocalDate borrowedOn;
    private final LocalDate dueDate;
    private final LocalDate returnedOn;

    public Loan(String id, String itemId, String memberId, LocalDate borrowedOn,
                LocalDate dueDate, LocalDate returnedOn) {
        this.id = requireText(id, "id");
        this.itemId = requireText(itemId, "itemId");
        this.memberId = requireText(memberId, "memberId");
        this.borrowedOn = Objects.requireNonNull(borrowedOn, "borrowedOn");
        this.dueDate = Objects.requireNonNull(dueDate, "dueDate");
        if (dueDate.isBefore(borrowedOn)) throw new IllegalArgumentException("Due date precedes borrow date");
        if (returnedOn != null && returnedOn.isBefore(borrowedOn)) {
            throw new IllegalArgumentException("Return date precedes borrow date");
        }
        this.returnedOn = returnedOn;
    }

    private static String requireText(String value, String field) {
        Objects.requireNonNull(value, field);
        if (value.isBlank()) throw new IllegalArgumentException(field + " cannot be blank");
        return value.trim();
    }

    public String id() { return id; }
    public String itemId() { return itemId; }
    public String memberId() { return memberId; }
    public LocalDate borrowedOn() { return borrowedOn; }
    public LocalDate dueDate() { return dueDate; }
    public LocalDate returnedOn() { return returnedOn; }
    public boolean isActive() { return returnedOn == null; }
    public boolean isOverdue(LocalDate today) { return isActive() && dueDate.isBefore(today); }

    @Override public String toString() {
        return "Loan " + id + ": item " + itemId + ", member " + memberId
                + ", due " + dueDate + (isActive() ? " [active]" : " [returned " + returnedOn + "]");
    }
}
