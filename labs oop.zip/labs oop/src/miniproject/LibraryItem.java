package miniproject;

import java.time.LocalDate;
import java.util.Objects;

public abstract class LibraryItem implements Borrowable {
    private final String title;
    private final String id;
    private Member borrowedBy;
    private LocalDate dueDate;

    protected LibraryItem(String title, String id) {
        this.title = requireText(title, "title");
        this.id = requireText(id, "id");
    }

    private static String requireText(String value, String field) {
        Objects.requireNonNull(value, field + " is required");
        if (value.isBlank()) throw new IllegalArgumentException(field + " cannot be blank");
        return value.trim();
    }

    public final String title() { return title; }
    public final String id() { return id; }
    public final boolean isAvailable() { return borrowedBy == null; }
    public final Member borrowedBy() { return borrowedBy; }
    public final LocalDate dueDate() { return dueDate; }
    public abstract int loanPeriodDays();
    public abstract String itemType();
    public abstract String csvDetails();

    @Override public final void borrow(Member member) throws ItemNotAvailableException {
        Objects.requireNonNull(member, "member");
        if (!isAvailable()) throw new ItemNotAvailableException(title + " is already on loan");
        borrowedBy = member;
        dueDate = LocalDate.now().plusDays(loanPeriodDays());
    }

    final void restoreBorrow(Member member, LocalDate dueDate) throws ItemNotAvailableException {
        Objects.requireNonNull(member, "member");
        Objects.requireNonNull(dueDate, "dueDate");
        if (!isAvailable()) throw new ItemNotAvailableException(title + " has more than one active loan");
        borrowedBy = member;
        this.dueDate = dueDate;
    }

    @Override public final void giveBack() {
        if (isAvailable()) throw new IllegalStateException("Item is not currently borrowed");
        borrowedBy = null;
        dueDate = null;
    }

    @Override public String toString() {
        return itemType() + " " + id + " - " + title
                + (isAvailable() ? " [available]" : " [due " + dueDate + "]");
    }
}
