package miniproject;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;
import java.util.stream.Collectors;

public final class Library {
    private static final int MAX_ACTIVE_LOANS = 3;
    private final Map<String, LibraryItem> items = new LinkedHashMap<>();
    private final Map<String, Member> members = new LinkedHashMap<>();
    private final Map<String, Loan> loans = new LinkedHashMap<>();
    private final Path dataDirectory;

    public Library(Path dataDirectory) {
        this.dataDirectory = Objects.requireNonNull(dataDirectory);
    }

    public Map<String, LibraryItem> items() { return Map.copyOf(items); }
    public Map<String, Member> members() { return Map.copyOf(members); }
    public Map<String, Loan> loans() { return Map.copyOf(loans); }

    public void addItem(LibraryItem item) {
        Objects.requireNonNull(item);
        if (items.putIfAbsent(item.id(), item) != null) {
            throw new IllegalArgumentException("An item with id " + item.id() + " already exists");
        }
    }

    public void registerMember(Member member) {
        Objects.requireNonNull(member);
        if (members.putIfAbsent(member.id(), member) != null) {
            throw new IllegalArgumentException("A member with id " + member.id() + " already exists");
        }
    }

    public Loan borrow(String itemId, String memberId)
            throws ItemNotAvailableException, MemberLimitExceededException {
        LibraryItem item = requireItem(itemId);
        Member member = requireMember(memberId);
        long activeCount = loans.values().stream()
                .filter(Loan::isActive)
                .filter(loan -> loan.memberId().equals(memberId))
                .count();
        if (activeCount >= MAX_ACTIVE_LOANS) {
            throw new MemberLimitExceededException(member.name() + " already has the maximum of "
                    + MAX_ACTIVE_LOANS + " active loans");
        }

        item.borrow(member);
        LocalDate borrowedOn = LocalDate.now();
        Loan loan = new Loan(UUID.randomUUID().toString(), item.id(), member.id(), borrowedOn,
                item.dueDate(), null);
        loans.put(loan.id(), loan);
        return loan;
    }

    public Loan giveBack(String itemId) {
        LibraryItem item = requireItem(itemId);
        if (item.isAvailable()) throw new IllegalStateException("Item " + itemId + " is not on loan");
        Loan activeLoan = loans.values().stream()
                .filter(Loan::isActive)
                .filter(loan -> loan.itemId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("Active loan record is missing for " + itemId));
        item.giveBack();
        Loan returnedLoan = new Loan(activeLoan.id(), activeLoan.itemId(), activeLoan.memberId(),
                activeLoan.borrowedOn(), activeLoan.dueDate(), LocalDate.now());
        loans.put(returnedLoan.id(), returnedLoan);
        return returnedLoan;
    }

    public List<LibraryItem> overdueItems(LocalDate today) {
        return loans.values().stream()
                .filter(loan -> loan.isOverdue(today))
                .map(loan -> requireItem(loan.itemId()))
                .toList();
    }

    public List<LibraryItem> searchByTitle(String query) {
        String normalized = Objects.requireNonNull(query).trim().toLowerCase();
        return items.values().stream()
                .filter(item -> item.title().toLowerCase().contains(normalized))
                .toList();
    }

    public void save() throws IOException {
        Files.createDirectories(dataDirectory);
        List<String> itemLines = new ArrayList<>();
        itemLines.add("type,id,title,detail1,detail2");
        for (LibraryItem item : items.values()) {
            String first = item instanceof Book book ? book.isbn()
                    : item instanceof Dvd dvd ? dvd.director() : "";
            String second = item instanceof Book book ? book.author() : "";
            itemLines.add(csv(item.itemType(), item.id(), item.title(), first, second));
        }
        Files.write(dataDirectory.resolve("items.csv"), itemLines);

        List<String> memberLines = new ArrayList<>();
        memberLines.add("id,name,email");
        for (Member member : members.values()) {
            memberLines.add(csv(member.id(), member.name(), member.email()));
        }
        Files.write(dataDirectory.resolve("members.csv"), memberLines);

        List<String> loanLines = new ArrayList<>();
        loanLines.add("id,itemId,memberId,borrowedOn,dueDate,returnedOn");
        for (Loan loan : loans.values()) {
            loanLines.add(csv(loan.id(), loan.itemId(), loan.memberId(), loan.borrowedOn().toString(),
                    loan.dueDate().toString(), loan.returnedOn() == null ? "" : loan.returnedOn().toString()));
        }
        Files.write(dataDirectory.resolve("loans.csv"), loanLines);
    }

    public void load() throws IOException {
        items.clear();
        members.clear();
        loans.clear();
        Path itemFile = dataDirectory.resolve("items.csv");
        Path memberFile = dataDirectory.resolve("members.csv");
        Path loanFile = dataDirectory.resolve("loans.csv");
        if (Files.exists(itemFile)) {
            for (List<String> row : readRows(itemFile, 5)) {
                String type = row.get(0);
                LibraryItem item = switch (type) {
                    case "BOOK" -> new Book(row.get(2), row.get(1), row.get(3), row.get(4));
                    case "DVD" -> new Dvd(row.get(2), row.get(1), row.get(3));
                    default -> throw new IOException("Unknown item type in " + itemFile + ": " + type);
                };
                addItem(item);
            }
        }
        if (Files.exists(memberFile)) {
            for (List<String> row : readRows(memberFile, 3)) {
                registerMember(new Member(row.get(0), row.get(1), row.get(2)));
            }
        }
        if (Files.exists(loanFile)) {
            for (List<String> row : readRows(loanFile, 6)) {
                LocalDate returnedOn = row.get(5).isEmpty() ? null : LocalDate.parse(row.get(5));
                Loan loan = new Loan(row.get(0), row.get(1), row.get(2), LocalDate.parse(row.get(3)),
                        LocalDate.parse(row.get(4)), returnedOn);
                if (!items.containsKey(loan.itemId()) || !members.containsKey(loan.memberId())) {
                    throw new IOException("Loan references an unknown item or member: " + loan.id());
                }
                if (loan.isActive()) {
                    try {
                        items.get(loan.itemId()).restoreBorrow(members.get(loan.memberId()), loan.dueDate());
                    } catch (ItemNotAvailableException exception) {
                        throw new IOException("Multiple active loans exist for item " + loan.itemId(), exception);
                    }
                }
                loans.put(loan.id(), loan);
            }
        }
    }

    private List<List<String>> readRows(Path file, int expectedColumns) throws IOException {
        List<String> lines = Files.readAllLines(file);
        List<List<String>> rows = new ArrayList<>();
        for (int index = 1; index < lines.size(); index++) {
            if (lines.get(index).isBlank()) continue;
            List<String> row;
            try {
                row = parseCsv(lines.get(index));
            } catch (IllegalArgumentException exception) {
                throw new IOException("Invalid CSV in " + file + " at line " + (index + 1), exception);
            }
            if (row.size() != expectedColumns) {
                throw new IOException("Expected " + expectedColumns + " columns in " + file
                        + " at line " + (index + 1));
            }
            rows.add(row);
        }
        return rows;
    }

    private static List<String> parseCsv(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        for (int index = 0; index < line.length(); index++) {
            char character = line.charAt(index);
            if (quoted) {
                if (character == '"' && index + 1 < line.length() && line.charAt(index + 1) == '"') {
                    field.append('"');
                    index++;
                } else if (character == '"') {
                    quoted = false;
                } else {
                    field.append(character);
                }
            } else if (character == ',') {
                fields.add(field.toString());
                field.setLength(0);
            } else if (character == '"' && field.length() == 0) {
                quoted = true;
            } else {
                field.append(character);
            }
        }
        if (quoted) throw new IllegalArgumentException("Unclosed quoted field");
        fields.add(field.toString());
        return fields;
    }

    private static String csv(String... fields) {
        return java.util.Arrays.stream(fields)
                .map(value -> "\"" + value.replace("\"", "\"\"") + "\"")
                .collect(Collectors.joining(","));
    }

    private LibraryItem requireItem(String id) {
        LibraryItem item = items.get(id);
        if (item == null) throw new IllegalArgumentException("Unknown item id: " + id);
        return item;
    }

    private Member requireMember(String id) {
        Member member = members.get(id);
        if (member == null) throw new IllegalArgumentException("Unknown member id: " + id);
        return member;
    }

    public static void main(String[] args) {
        Path dataDirectory = Path.of("library-data");
        Library library = new Library(dataDirectory);
        try {
            library.load();
            System.out.println("Loaded " + library.items.size() + " items and "
                    + library.members.size() + " members from " + dataDirectory.toAbsolutePath());
            runMenu(library);
        } catch (IOException exception) {
            System.err.println("Unable to load library data: " + exception.getMessage());
            return;
        }
        try {
            library.save();
            System.out.println("Library data saved.");
        } catch (IOException exception) {
            System.err.println("Unable to save library data: " + exception.getMessage());
        }
    }

    private static void runMenu(Library library) {
        try (Scanner scanner = new Scanner(System.in)) {
            boolean running = true;
            while (running) {
                System.out.println("""
                        \nLibrary menu
                        1. Add item
                        2. Register member
                        3. Borrow item
                        4. Return item
                        5. List overdue items
                        6. Search by title
                        7. List all items and members
                        0. Save and exit""");
                System.out.print("Choice: ");
                String choice = scanner.nextLine().trim();
                try {
                    switch (choice) {
                        case "1" -> addItemFromMenu(library, scanner);
                        case "2" -> registerMemberFromMenu(library, scanner);
                        case "3" -> {
                            System.out.print("Item id: ");
                            String itemId = scanner.nextLine().trim();
                            System.out.print("Member id: ");
                            String memberId = scanner.nextLine().trim();
                            System.out.println("Borrowed: " + library.borrow(itemId, memberId));
                        }
                        case "4" -> {
                            System.out.print("Item id: ");
                            System.out.println("Returned: " + library.giveBack(scanner.nextLine().trim()));
                        }
                        case "5" -> library.overdueItems(LocalDate.now()).forEach(System.out::println);
                        case "6" -> {
                            System.out.print("Title search: ");
                            List<LibraryItem> matches = library.searchByTitle(scanner.nextLine());
                            matches.forEach(System.out::println);
                            if (matches.isEmpty()) System.out.println("No matching titles.");
                        }
                        case "7" -> {
                            library.items.values().forEach(System.out::println);
                            library.members.values().forEach(System.out::println);
                        }
                        case "0" -> running = false;
                        default -> System.out.println("Choose a listed menu number.");
                    }
                } catch (ItemNotAvailableException | MemberLimitExceededException
                         | IllegalArgumentException | IllegalStateException exception) {
                    System.out.println("Operation failed: " + exception.getMessage());
                }
            }
        }
    }

    private static void addItemFromMenu(Library library, Scanner scanner) {
        System.out.print("Type (book/dvd): ");
        String type = scanner.nextLine().trim().toLowerCase();
        System.out.print("Id: ");
        String id = scanner.nextLine().trim();
        System.out.print("Title: ");
        String title = scanner.nextLine().trim();
        if (type.equals("book")) {
            System.out.print("ISBN: ");
            String isbn = scanner.nextLine().trim();
            System.out.print("Author: ");
            library.addItem(new Book(title, id, isbn, scanner.nextLine().trim()));
        } else if (type.equals("dvd")) {
            System.out.print("Director: ");
            library.addItem(new Dvd(title, id, scanner.nextLine().trim()));
        } else {
            throw new IllegalArgumentException("Type must be book or dvd");
        }
        System.out.println("Item added.");
    }

    private static void registerMemberFromMenu(Library library, Scanner scanner) {
        System.out.print("Member id: ");
        String id = scanner.nextLine().trim();
        System.out.print("Name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Email: ");
        library.registerMember(new Member(id, name, scanner.nextLine().trim()));
        System.out.println("Member registered.");
    }
}
