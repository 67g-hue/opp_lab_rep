package miniproject;

import java.util.Objects;

public final class Dvd extends LibraryItem {
    private final String director;

    public Dvd(String title, String id, String director) {
        super(title, id);
        Objects.requireNonNull(director, "director");
        if (director.isBlank()) throw new IllegalArgumentException("Director cannot be blank");
        this.director = director.trim();
    }

    public String director() { return director; }
    @Override public int loanPeriodDays() { return 7; }
    @Override public String itemType() { return "DVD"; }
    @Override public String csvDetails() { return director; }
    @Override public String toString() { return super.toString() + " directed by " + director; }
}
