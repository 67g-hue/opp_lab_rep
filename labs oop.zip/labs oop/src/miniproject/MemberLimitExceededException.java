package miniproject;

public class MemberLimitExceededException extends Exception {
    private static final long serialVersionUID = 1L;
    public MemberLimitExceededException(String message) { super(message); }
}
