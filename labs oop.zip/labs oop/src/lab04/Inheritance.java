package lab04;

import java.util.ArrayList;
import java.util.List;

public class Inheritance {
    static class Person {
        final String name;
        final int age;
        Person(String name, int age) { this.name = name; this.age = age; }
        void display() { System.out.println(name + ", age " + age); }
    }
    static class Student extends Person {
        final String course;
        Student(String name, int age, String course) { super(name, age); this.course = course; }
        @Override void display() { super.display(); System.out.println("Course: " + course); }
    }
    static class Teacher extends Person {
        final String subject;
        Teacher(String name, int age, String subject) { super(name, age); this.subject = subject; }
        @Override void display() { super.display(); System.out.println("Subject: " + subject); }
    }

    static class Vehicle {
        Vehicle() { System.out.println("Vehicle constructor"); }
    }
    static class Car extends Vehicle {
        Car() { System.out.println("Car constructor"); }
    }
    static class ElectricCar extends Car {
        ElectricCar() { System.out.println("ElectricCar constructor"); }
    }

    static class NamedAnimal {
        final String name;
        NamedAnimal(String name) { this.name = name; }
    }
    // `class DogWithoutSuper extends NamedAnimal { }` does not compile: it implies super().
    static class Dog extends NamedAnimal {
        Dog(String name) { super(name); }
    }

    static class ComposedStack<T> {
        private final List<T> values = new ArrayList<>();
        void push(T value) { values.add(value); }
        T pop() {
            if (values.isEmpty()) throw new IllegalStateException("Stack is empty");
            return values.remove(values.size() - 1);
        }
        boolean isEmpty() { return values.isEmpty(); }
    }

    public static void main(String[] args) {
        new Student("Asha", 19, "Computer Science").display();
        new Teacher("Mr. Kim", 42, "Java").display();
        System.out.println("Constructor order:");
        new ElectricCar();
        Dog dog = new Dog("Milo");
        System.out.println("Dog's required superclass name: " + dog.name);
        System.out.println("A Dog constructor without super(name) fails because NamedAnimal has no no-argument constructor.");
        ComposedStack<Integer> stack = new ComposedStack<>();
        stack.push(1);
        System.out.println("Composed stack pop: " + stack.pop());
        System.out.println("Composition exposes only stack operations, unlike extends ArrayList which exposes indexed insertion/removal.");
        System.out.println("A subclass must call the required superclass constructor with super(name).");
    }
}
