package lab02;

public class ConstructorsAndStatic {
    static class Circle {
        private static int count;
        private final double radius;

        Circle() { this(1.0); }
        Circle(double radius) {
            if (radius <= 0) throw new IllegalArgumentException("Radius must be positive");
            this.radius = radius;
            count++;
        }
        double area() { return Math.PI * radius * radius; }
        static int getCount() { return count; }
    }

    static class Employee {
        private static int nextId = 1;
        final int employeeId;
        final String name;
        final String role;
        final double salary;

        Employee(String name) { this(name, "Unassigned", 0); }
        Employee(String name, String role) { this(name, role, 0); }
        Employee(String name, String role, double salary) {
            this.employeeId = nextId++;
            this.name = name;
            this.role = role;
            this.salary = salary;
        }
        Employee(Employee source) { this(source.name, source.role, source.salary); }
        @Override public String toString() {
            return employeeId + ": " + name + ", " + role + ", $" + salary;
        }
    }

    static class InitializationOrder {
        static { System.out.println("static block 1"); }
        static { System.out.println("static block 2"); }
        { System.out.println("instance block 1"); }
        { System.out.println("instance block 2"); }
        InitializationOrder() { System.out.println("constructor"); }
    }

    static class Temperature {
        private final double celsius;
        private Temperature(double celsius) { this.celsius = celsius; }
        static Temperature fromCelsius(double value) {
            if (value < -273.15) throw new IllegalArgumentException("Below absolute zero");
            return new Temperature(value);
        }
        static Temperature fromFahrenheit(double value) {
            return fromCelsius((value - 32) * 5 / 9);
        }
        double celsius() { return celsius; }
        double fahrenheit() { return celsius * 9 / 5 + 32; }
    }

    public static void main(String[] args) {
        Circle first = new Circle();
        Circle second = new Circle(2.5);
        System.out.printf("Circle areas: %.2f, %.2f; count=%d%n",
                first.area(), second.area(), Circle.getCount());

        Employee employee = new Employee("Sam", "Developer", 52000);
        System.out.println(employee);
        System.out.println(new Employee("Alex"));
        System.out.println(new Employee("Jo", "Designer"));
        System.out.println(new Employee(employee));

        System.out.println("Initialization order (predict before running):");
        new InitializationOrder();
        System.out.println("Static factories name the unit at each call site: "
                + Temperature.fromCelsius(20).celsius() + " C; "
                + Temperature.fromFahrenheit(68).celsius() + " C");
    }
}
