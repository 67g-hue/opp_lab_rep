package lab06;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AbstractionAndInterfaces {
    abstract static class Shape {
        abstract double area();
        abstract double perimeter();
    }
    static class Circle extends Shape {
        final double radius;
        Circle(double radius) { this.radius = radius; }
        @Override double area() { return Math.PI * radius * radius; }
        @Override double perimeter() { return 2 * Math.PI * radius; }
    }
    static class Rectangle extends Shape {
        final double width, height;
        Rectangle(double width, double height) { this.width = width; this.height = height; }
        @Override double area() { return width * height; }
        @Override double perimeter() { return 2 * (width + height); }
    }
    static class Square extends Rectangle {
        Square(double side) { super(side, side); }
    }

    interface Flyable { void fly(); }
    static class Bird implements Flyable { @Override public void fly() { System.out.println("Bird flaps"); } }
    static class Aeroplane implements Flyable { @Override public void fly() { System.out.println("Aeroplane uses engines"); } }

    abstract static class Account {
        private double balance;
        void deposit(double amount) {
            if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
            balance += amount;
        }
        double balance() { return balance; }
        abstract double monthlyFee();
    }
    static class SavingsAccount extends Account { @Override double monthlyFee() { return 2.5; } }
    static class CurrentAccount extends Account { @Override double monthlyFee() { return 10; } }

    record Student(String name, int marks) implements Comparable<Student> {
        @Override public int compareTo(Student other) { return name.compareToIgnoreCase(other.name); }
        @Override public String toString() { return name + " (" + marks + ")"; }
    }
    interface GreeterA { default void hello() { System.out.println("Hello from A"); } }
    interface GreeterB { default void hello() { System.out.println("Hello from B"); } }
    static class Greeter implements GreeterA, GreeterB {
        @Override public void hello() {
            GreeterA.super.hello();
            GreeterB.super.hello();
        }
    }

    public static void main(String[] args) {
        Shape[] shapes = {new Circle(2), new Rectangle(3, 4), new Square(3)};
        for (Shape shape : shapes) System.out.printf("Area %.2f, perimeter %.2f%n", shape.area(), shape.perimeter());
        Flyable[] flyers = {new Bird(), new Aeroplane()};
        for (Flyable flyer : flyers) flyer.fly();
        Account account = new SavingsAccount();
        account.deposit(50);
        System.out.println("Savings balance " + account.balance() + ", fee " + account.monthlyFee());
        account = new CurrentAccount();
        System.out.println("Current account fee " + account.monthlyFee());
        List<Student> students = new ArrayList<>(List.of(
                new Student("Zed", 70), new Student("Ada", 95), new Student("Bo", 82)));
        students.sort(null);
        System.out.println("By name: " + students);
        students.sort(Comparator.comparingInt(Student::marks).reversed());
        System.out.println("By marks: " + students);
        new Greeter().hello();
        System.out.println("A class resolving two unrelated defaults must override hello(); InterfaceName.super selects a specific default.");
    }
}
