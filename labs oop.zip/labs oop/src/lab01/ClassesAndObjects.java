package lab01;

import java.time.Year;

public class ClassesAndObjects {
    static class Car {
        String brand;
        int year;
        double mileage;

        Car(String brand, int year, double mileage) {
            this.brand = brand;
            this.year = year;
            this.mileage = mileage;
        }

        void display() {
            System.out.printf("%s (%d), %.1f km%n", brand, year, mileage);
        }

        boolean isAntique() {
            return Year.now().getValue() - year > 25;
        }
    }

    static class Rectangle {
        double width;
        double height;

        Rectangle(double width, double height) {
            this.width = width;
            this.height = height;
        }

        double area() { return width * height; }
        double perimeter() { return 2 * (width + height); }
    }

    static class Address {
        String city;
        Address(String city) { this.city = city; }
    }

    static class Person {
        String name;
        Address address;
        Person(String name, Address address) {
            this.name = name;
            this.address = address;
        }
    }

    public static void main(String[] args) {
        Car[] cars = {
            new Car("Toyota", 1998, 180_000),
            new Car("Honda", 2018, 54_200),
            new Car("Volvo", 2005, 130_000)
        };
        for (Car car : cars) {
            car.display();
            System.out.println("Antique: " + car.isAntique());
        }

        Rectangle[] rectangles = {
            new Rectangle(2, 8), new Rectangle(4, 5), new Rectangle(7, 3),
            new Rectangle(6, 6), new Rectangle(10, 2)
        };
        Rectangle largest = rectangles[0];
        for (Rectangle rectangle : rectangles) {
            if (rectangle.area() > largest.area()) largest = rectangle;
        }
        System.out.printf("Largest rectangle: %.1f x %.1f; area=%.1f; perimeter=%.1f%n",
                largest.width, largest.height, largest.area(), largest.perimeter());

        Rectangle r1 = new Rectangle(3, 4);
        Rectangle r2 = r1;
        r2.width = 9;
        System.out.println("r1.width after changing r2.width: " + r1.width
                + " (both variables refer to the same object)");

        Person person = new Person("Amina", new Address("Nairobi"));
        System.out.println("City: " + person.address.city);
        Person noAddress = new Person("Lee", null);
        try {
            System.out.println(noAddress.address.city);
        } catch (NullPointerException exception) {
            System.out.println("Chained access with a null address throws NullPointerException.");
        }
    }
}
