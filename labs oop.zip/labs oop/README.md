# Java OOP Labs and Library Mini-Project

Each lab is a separate Java package with a runnable demonstration class. The examples are kept in distinct files and packages so repeated classroom names such as `Student`, `Book`, `Circle`, and `Rectangle` do not conflict.

## Requirements

Install JDK 17 or later. The source uses records, switch expressions, text blocks, and pattern matching for `instanceof`.

## Compile

From this folder in PowerShell:

```powershell
New-Item -ItemType Directory -Force out | Out-Null
javac -d out (Get-ChildItem -Recurse src -Filter *.java | ForEach-Object FullName)
```

## Run a lab

```powershell
java -cp out lab01.ClassesAndObjects
```

Runnable main classes:

- `lab01.ClassesAndObjects`
- `lab02.ConstructorsAndStatic`
- `lab03.Encapsulation`
- `lab04.Inheritance`
- `lab05.Polymorphism`
- `lab06.AbstractionAndInterfaces`
- `lab07.Exceptions` (prompts for two integers)
- `lab08.CollectionsAndGenerics`
- `lab09.TypesAndObjectContract`
- `lab10.FilesLambdasAndStreams` (prompts for five lines; alternatively pass exactly five command-line arguments)
- `miniproject.Library`

Lab 10 writes sample output to `lab10-output`. If `learners.csv` exists in the working directory, it expects a header followed by `name,mark` rows and writes three grade reports there.

## Library mini-project

Run `miniproject.Library`. It creates/loads `library-data\items.csv`, `members.csv`, and `loans.csv`, provides a console menu, and saves on exit. Items and members are keyed by IDs; active loans survive a restart and keep their original due dates. Books may be borrowed for 21 days and DVDs for 7 days. Each member may have at most three active loans.

### Design report

`LibraryItem` is abstract and implements `Borrowable`; `Book` and `Dvd` supply their own loan periods and type-specific data. The `Library` owns maps of items, members, and loan records, and handles the loan limit, CSV persistence, search, and overdue filtering. Validation is performed in domain constructors and service operations. `ItemNotAvailableException` and `MemberLimitExceededException` distinguish common borrow failures; malformed data and I/O errors are reported rather than silently ignored.

### Class diagram

```text
                         <<interface>> Borrowable
                         + borrow(Member)
                         + giveBack()
                                  ^
                                  |
                         LibraryItem (abstract)
                         - id, title, borrowedBy, dueDate
                         + loanPeriodDays()
                           ^             ^
                           |             |
                     Book                Dvd
                     - isbn, author      - director

  Library
  - Map<String, LibraryItem> items
  - Map<String, Member> members
  - Map<String, Loan> loans
  + add/register/borrow/giveBack/search/overdue/load/save

  Loan - id, itemId, memberId, borrowedOn, dueDate, returnedOn
  Member - id, name, email
```

The lab demos print results for the prediction questions that can be verified by running code; the notes below explain the expected behavior and design choices.

### Lab explanation notes

- **Lab 1:** `r2 = r1` copies the object reference, not the rectangle. Both variables point to the same object, so changing `r2.width` is visible through `r1`. A chained address access throws `NullPointerException` if `address` is null; callers should check it or model optional data explicitly.
- **Lab 2:** Static initialization blocks run once, in source order, before the first instance is created. Instance initialization blocks run in source order for each new instance, immediately before its constructor body. Factory methods make units explicit at the call site (`fromCelsius` versus `fromFahrenheit`) and do not need ambiguous same-shaped constructors.
- **Lab 3:** `ImmutablePerson` is final so it cannot be subclassed with mutable behavior; its fields are private and final, initialized once, and exposed only through accessors. A private Kelvin field with Celsius/Fahrenheit accessors also lets callers remain independent of the storage unit.
- **Lab 4:** `Dog` must call `super(name)` because Java inserts `super()` when a constructor omits a superclass call, and the superclass has no no-argument constructor. Extending `ArrayList` for a stack exposes arbitrary list operations (such as inserting/removing at any index), which violate the stack abstraction; composition exposes only the intended stack operations.
- **Lab 5:** Overridden methods dispatch according to the runtime object; fields are selected according to the declared reference type. An `instanceof` payment processor must change when a new payment type is added, while polymorphic `process()` lets each payment own its behavior and leaves the processing loop unchanged.
- **Lab 6:** If unrelated interfaces provide the same default method, the implementing class must override it and explicitly choose or combine implementations with `InterfaceName.super.method()`.
- **Lab 7:** A checked exception makes the caller handle or declare a recoverable failure; it separates exceptional withdrawal from normal return values but adds handling at call sites. `finally` runs as control leaves `try` even when `try` returns (except when the process is forcibly terminated or the JVM exits).
- **Lab 8:** Java generics work with reference types, so `T` cannot be the primitive `int`; use the wrapper `Integer[]` (autoboxing applies to individual values, not primitive arrays).
- **Lab 9:** `HashSet` uses `hashCode()` to select a bucket and `equals()` to detect equal entries. Both must use the same identity rule (here, ISBN), or duplicate detection can fail.
